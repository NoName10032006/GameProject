using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockToUsed : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;  // Komponent SpriteRenderer

    void Start()
    {
        // Pobierz komponent SpriteRenderer podczas Start, aby unikn�� zb�dnych wywo�a� w ka�dej klatce
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Wczytaj Sprite z pliku przy u�yciu Resources.Load
            Sprite mojSprite = Resources.Load<Sprite>("usedblock");

            // Sprawd�, czy Sprite zosta� prawid�owo wczytany
            if (mojSprite != null)
            {
                // Przypisz wczytany Sprite do w�a�ciwo�ci sprite komponentu SpriteRenderer
                spriteRenderer.sprite = mojSprite;
            }
            else
            {
                Debug.LogError("Nie uda�o si� wczyta� Sprite'a z pliku.");
            }
        }
    }
}
